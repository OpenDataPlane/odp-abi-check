/* Copyright (c) 2015, Linaro Limited
 * All rights reserved.
 *
 * SPDX-License-Identifier:     BSD-3-Clause
 */

#include "thread.h"

int main(int argc, char *argv[])
{
	return thread_main(argc, argv);
}
