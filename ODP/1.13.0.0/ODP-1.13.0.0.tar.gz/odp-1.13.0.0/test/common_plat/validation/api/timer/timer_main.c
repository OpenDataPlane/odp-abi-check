/* Copyright (c) 2015, Linaro Limited
 * All rights reserved.
 *
 * SPDX-License-Identifier:     BSD-3-Clause
 */

#include "timer.h"

int main(int argc, char *argv[])
{
	return timer_main(argc, argv);
}
