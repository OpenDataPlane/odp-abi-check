/* Copyright (c) 2016, Linaro Limited
 * All rights reserved.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

/**
 * @file
 *
 * Ticketlock inline functions
 */

#ifndef _ODP_PLAT_TICKETLOCK_INLINES_H_
#define _ODP_PLAT_TICKETLOCK_INLINES_H_

#include <odp/api/atomic.h>
#include <odp/api/sync.h>
#include <odp/api/cpu.h>

#include <odp/api/plat/ticketlock_types.h>

/** @internal
 * Acquire ticket lock.
 *
 * @param ticketlock Pointer to a ticket lock
 */
static inline void _odp_ticketlock_lock(odp_ticketlock_t *ticketlock)
{
	uint32_t ticket;

	/* Take a ticket using an atomic increment of 'next_ticket'.
	 * This can be a relaxed operation but it cannot have the
	 * acquire semantics since we haven't acquired the lock yet */
	ticket = odp_atomic_fetch_inc_u32(&ticketlock->next_ticket);

	/* Spin waiting for our turn. Use load-acquire so that we acquire
	 * all stores from the previous lock owner */
	while (ticket != odp_atomic_load_acq_u32(&ticketlock->cur_ticket))
		odp_cpu_pause();
}

/** @internal
 * Try to acquire ticket lock.
 *
 * @param tklock Pointer to a ticket lock
 *
 * @retval 1 lock acquired
 * @retval 0 lock not acquired
 */
static inline int _odp_ticketlock_trylock(odp_ticketlock_t *tklock)
{
	/* We read 'next_ticket' and 'cur_ticket' non-atomically which should
	 * not be a problem as they are not independent of each other.
	 * 'cur_ticket' is always <= to 'next_ticket' and if we see an
	 * older value of 'cur_ticket', this only means the lock will
	 * look busy and trylock will fail. */
	uint32_t next = odp_atomic_load_u32(&tklock->next_ticket);
	uint32_t cur = odp_atomic_load_u32(&tklock->cur_ticket);
	/* First check that lock is available and possible to take without
	 * spinning. */
	if (next == cur) {
		/* Then try to take the lock by incrementing 'next_ticket'
		 * but only if it still has the original value which is
		 * equal to 'cur_ticket'.
		 * We don't have to include 'cur_ticket' in the comparison
		 * because it cannot be larger than 'next_ticket' (only
		 * smaller if the lock is busy).
		 * If CAS fails, it means some other thread intercepted and
		 * took a ticket which means the lock is not available
		 * anymore */
		if (odp_atomic_cas_acq_u32(&tklock->next_ticket,
					   &next, next + 1))
			return 1;
	}
	return 0;
}

/** @internal
 * Release ticket lock
 *
 * @param ticketlock Pointer to a ticket lock
 */
static inline void _odp_ticketlock_unlock(odp_ticketlock_t *ticketlock)
{
	/* Release the lock by incrementing 'cur_ticket'. As we are the
	 * lock owner and thus the only thread that is allowed to write
	 * 'cur_ticket', we don't need to do this with an (expensive)
	 * atomic RMW operation. Instead load-relaxed the current value
	 * and a store-release of the incremented value */
	uint32_t cur = odp_atomic_load_u32(&ticketlock->cur_ticket);

	odp_atomic_store_rel_u32(&ticketlock->cur_ticket, cur + 1);
}

/** @internal
 * Check if ticket lock is locked
 *
 * @param ticketlock Pointer to a ticket lock
 *
 * @retval 1 the lock is busy (locked)
 * @retval 0 the lock is available (unlocked)
 */
static inline int _odp_ticketlock_is_locked(odp_ticketlock_t *ticketlock)
{
	/* Compare 'cur_ticket' with 'next_ticket'. Ideally we should read
	 * both variables atomically but the information can become stale
	 * immediately anyway so the function can only be used reliably in
	 * a quiescent system where non-atomic loads should not pose a
	 * problem */
	return odp_atomic_load_u32(&ticketlock->cur_ticket) !=
		odp_atomic_load_u32(&ticketlock->next_ticket);
}

/* Include inlined versions of API functions */
#include <odp/api/plat/static_inline.h>
#if ODP_ABI_COMPAT == 0

/** @ingroup odp_locks
 *  @{
 */

#include <odp/api/plat/ticketlock_inlines_api.h>

/**
 * @}
 */

#endif

#endif
