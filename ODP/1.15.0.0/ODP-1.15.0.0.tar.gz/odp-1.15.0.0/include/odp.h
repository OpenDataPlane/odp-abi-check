/* Copyright (c) 2016, Linaro Limited
 * All rights reserved
 *
 * SPDX-License-Identifier:     BSD-3-Clause
 */

/**
 * @file
 *
 * WARNING: THIS FILE IS DEPRECATED AND WILL BE REMOVED!!!
 * ODP APPLICATIONS SHOULD NOW INCLUDE odp_api.h INSTEAD.
 *
 * This file is here to ease the transition period but will be removed.
 * This change has been made to enable the creation of other ODP interfaces.
 *
 */

#ifndef ODP_H_
#define ODP_H_

#include <odp_api.h>

#endif
