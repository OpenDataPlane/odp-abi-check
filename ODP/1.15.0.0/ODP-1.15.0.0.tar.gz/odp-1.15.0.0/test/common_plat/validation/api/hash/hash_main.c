/* Copyright (c) 2015, Linaro Limited
 * All rights reserved.
 *
 * SPDX-License-Identifier:     BSD-3-Clause
 */

#include "hash.h"

int main(int argc, char *argv[])
{
	return hash_main(argc, argv);
}
