/* Copyright (c) 2016, Linaro Limited
 * All rights reserved.
 *
 * SPDX-License-Identifier:     BSD-3-Clause
 */

#include "ring_suites.h"

int main(int argc, char *argv[])
{
	return ring_suites_main(argc, argv);
}
