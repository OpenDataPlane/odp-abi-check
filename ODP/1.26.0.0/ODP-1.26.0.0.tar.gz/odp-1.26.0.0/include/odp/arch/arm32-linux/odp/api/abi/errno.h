/* Copyright (c) 2020, Marvell
 * All rights reserved.
 *
 * SPDX-License-Identifier:     BSD-3-Clause
 */

#include <odp/api/abi-default/errno.h>
