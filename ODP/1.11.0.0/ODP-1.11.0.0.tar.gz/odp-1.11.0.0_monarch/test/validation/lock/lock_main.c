/* Copyright (c) 2015, Linaro Limited
 * All rights reserved.
 *
 * SPDX-License-Identifier:     BSD-3-Clause
 */

#include "lock.h"

int main(int argc, char *argv[])
{
	return lock_main(argc, argv);
}
