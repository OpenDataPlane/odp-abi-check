/* Copyright (c) 2016, Linaro Limited
 * All rights reserved.
 *
 * SPDX-License-Identifier:	BSD-3-Clause
 */

/*
 * @file
 *
 * Linker visibility directives
 */

#if __GNUC__ >= 4
#pragma GCC visibility pop
#endif
