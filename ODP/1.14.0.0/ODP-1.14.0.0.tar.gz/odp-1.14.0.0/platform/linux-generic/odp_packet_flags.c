/* Copyright (c) 2014, Linaro Limited
 * All rights reserved.
 *
 * SPDX-License-Identifier:     BSD-3-Clause
 */

#include <odp/api/plat/packet_flag_inlines.h>
#include <odp/api/packet_flags.h>
#include <odp_packet_internal.h>

#define retflag(pkt, x, layer) do {                      \
	odp_packet_hdr_t *pkt_hdr = odp_packet_hdr(pkt); \
	if (pkt_hdr->p.parsed_layers < layer)            \
		packet_parse_layer(pkt_hdr, layer);      \
	return pkt_hdr->p.x;                             \
	} while (0)

#define setflag(pkt, x, v, layer) do {                   \
	odp_packet_hdr_t *pkt_hdr = odp_packet_hdr(pkt); \
	if (pkt_hdr->p.parsed_layers < layer)            \
		packet_parse_layer(pkt_hdr, layer);      \
	pkt_hdr->p.x = v & 1;                            \
	} while (0)

int odp_packet_has_error(odp_packet_t pkt)
{
	odp_packet_hdr_t *pkt_hdr = odp_packet_hdr(pkt);

	if (packet_parse_not_complete(pkt_hdr))
		packet_parse_layer(pkt_hdr, LAYER_ALL);
	return odp_packet_hdr(pkt)->p.error_flags.all != 0;
}

/* Get Input Flags */

int odp_packet_has_l2_error(odp_packet_t pkt)
{
	odp_packet_hdr_t *pkt_hdr = odp_packet_hdr(pkt);
	/* L2 parsing is always done by default and hence
	no additional check is required */
	return pkt_hdr->p.error_flags.frame_len
		| pkt_hdr->p.error_flags.snap_len
		| pkt_hdr->p.error_flags.l2_chksum;
}

int odp_packet_has_l3(odp_packet_t pkt)
{
	retflag(pkt, input_flags.l3, LAYER_L3);
}

int odp_packet_has_l3_error(odp_packet_t pkt)
{
	odp_packet_hdr_t *pkt_hdr = odp_packet_hdr(pkt);

	if (pkt_hdr->p.parsed_layers < LAYER_L3)
		packet_parse_layer(pkt_hdr, LAYER_L3);

	return pkt_hdr->p.error_flags.ip_err;
}

int odp_packet_has_l4(odp_packet_t pkt)
{
	retflag(pkt, input_flags.l4, LAYER_L4);
}

int odp_packet_has_l4_error(odp_packet_t pkt)
{
	odp_packet_hdr_t *pkt_hdr = odp_packet_hdr(pkt);

	if (pkt_hdr->p.parsed_layers < LAYER_L4)
		packet_parse_layer(pkt_hdr, LAYER_L4);

	return pkt_hdr->p.error_flags.tcp_err | pkt_hdr->p.error_flags.udp_err;
}

int odp_packet_has_eth_bcast(odp_packet_t pkt)
{
	retflag(pkt, input_flags.eth_bcast, LAYER_L2);
}

int odp_packet_has_eth_mcast(odp_packet_t pkt)
{
	retflag(pkt, input_flags.eth_mcast, LAYER_L2);
}

int odp_packet_has_vlan(odp_packet_t pkt)
{
	retflag(pkt, input_flags.vlan, LAYER_L2);
}

int odp_packet_has_vlan_qinq(odp_packet_t pkt)
{
	retflag(pkt, input_flags.vlan_qinq, LAYER_L2);
}

int odp_packet_has_arp(odp_packet_t pkt)
{
	retflag(pkt, input_flags.arp, LAYER_L3);
}

int odp_packet_has_ipv4(odp_packet_t pkt)
{
	retflag(pkt, input_flags.ipv4, LAYER_L3);
}

int odp_packet_has_ipv6(odp_packet_t pkt)
{
	retflag(pkt, input_flags.ipv6, LAYER_L3);
}

int odp_packet_has_ip_bcast(odp_packet_t pkt)
{
	retflag(pkt, input_flags.ip_bcast, LAYER_L3);
}

int odp_packet_has_ip_mcast(odp_packet_t pkt)
{
	retflag(pkt, input_flags.ip_mcast, LAYER_L3);
}

int odp_packet_has_ipfrag(odp_packet_t pkt)
{
	retflag(pkt, input_flags.ipfrag, LAYER_L3);
}

int odp_packet_has_ipopt(odp_packet_t pkt)
{
	retflag(pkt, input_flags.ipopt, LAYER_L3);
}

int odp_packet_has_ipsec(odp_packet_t pkt)
{
	retflag(pkt, input_flags.ipsec, LAYER_L4);
}

int odp_packet_has_udp(odp_packet_t pkt)
{
	retflag(pkt, input_flags.udp, LAYER_L4);
}

int odp_packet_has_tcp(odp_packet_t pkt)
{
	retflag(pkt, input_flags.tcp, LAYER_L4);
}

int odp_packet_has_sctp(odp_packet_t pkt)
{
	retflag(pkt, input_flags.sctp, LAYER_L4);
}

int odp_packet_has_icmp(odp_packet_t pkt)
{
	retflag(pkt, input_flags.icmp, LAYER_L4);
}

odp_packet_color_t odp_packet_color(odp_packet_t pkt)
{
	retflag(pkt, input_flags.color, LAYER_ALL);
}

void odp_packet_color_set(odp_packet_t pkt, odp_packet_color_t color)
{
	odp_packet_hdr_t *pkt_hdr = odp_packet_hdr(pkt);

	if (packet_parse_not_complete(pkt_hdr))
		packet_parse_layer(pkt_hdr, LAYER_ALL);

	pkt_hdr->p.input_flags.color = color;
}

odp_bool_t odp_packet_drop_eligible(odp_packet_t pkt)
{
	odp_packet_hdr_t *pkt_hdr = odp_packet_hdr(pkt);

	if (packet_parse_not_complete(pkt_hdr))
		packet_parse_layer(pkt_hdr, LAYER_ALL);

	return !pkt_hdr->p.input_flags.nodrop;
}

void odp_packet_drop_eligible_set(odp_packet_t pkt, odp_bool_t drop)
{
	setflag(pkt, input_flags.nodrop, !drop, LAYER_ALL);
}

int8_t odp_packet_shaper_len_adjust(odp_packet_t pkt)
{
	retflag(pkt, output_flags.shaper_len_adj, LAYER_ALL);
}

void odp_packet_shaper_len_adjust_set(odp_packet_t pkt, int8_t adj)
{
	odp_packet_hdr_t *pkt_hdr = odp_packet_hdr(pkt);

	if (packet_parse_not_complete(pkt_hdr))
		packet_parse_layer(pkt_hdr, LAYER_ALL);

	pkt_hdr->p.output_flags.shaper_len_adj = adj;
}

/* Set Input Flags */

void odp_packet_has_l2_set(odp_packet_t pkt, int val)
{
	setflag(pkt, input_flags.l2, val, LAYER_L2);
}

void odp_packet_has_l3_set(odp_packet_t pkt, int val)
{
	setflag(pkt, input_flags.l3, val, LAYER_L3);
}

void odp_packet_has_l4_set(odp_packet_t pkt, int val)
{
	setflag(pkt, input_flags.l4, val, LAYER_L4);
}

void odp_packet_has_eth_set(odp_packet_t pkt, int val)
{
	setflag(pkt, input_flags.eth, val, LAYER_L2);
}

void odp_packet_has_eth_bcast_set(odp_packet_t pkt, int val)
{
	setflag(pkt, input_flags.eth_bcast, val, LAYER_L2);
}

void odp_packet_has_eth_mcast_set(odp_packet_t pkt, int val)
{
	setflag(pkt, input_flags.eth_mcast, val, LAYER_L2);
}

void odp_packet_has_jumbo_set(odp_packet_t pkt, int val)
{
	setflag(pkt, input_flags.jumbo, val, LAYER_L2);
}

void odp_packet_has_vlan_set(odp_packet_t pkt, int val)
{
	setflag(pkt, input_flags.vlan, val, LAYER_L2);
}

void odp_packet_has_vlan_qinq_set(odp_packet_t pkt, int val)
{
	setflag(pkt, input_flags.vlan_qinq, val, LAYER_L2);
}

void odp_packet_has_arp_set(odp_packet_t pkt, int val)
{
	setflag(pkt, input_flags.arp, val, LAYER_L3);
}

void odp_packet_has_ipv4_set(odp_packet_t pkt, int val)
{
	setflag(pkt, input_flags.ipv4, val, LAYER_L3);
}

void odp_packet_has_ipv6_set(odp_packet_t pkt, int val)
{
	setflag(pkt, input_flags.ipv6, val, LAYER_L3);
}

void odp_packet_has_ip_bcast_set(odp_packet_t pkt, int val)
{
	setflag(pkt, input_flags.ip_bcast, val, LAYER_L3);
}

void odp_packet_has_ip_mcast_set(odp_packet_t pkt, int val)
{
	setflag(pkt, input_flags.ip_mcast, val, LAYER_L3);
}

void odp_packet_has_ipfrag_set(odp_packet_t pkt, int val)
{
	setflag(pkt, input_flags.ipfrag, val, LAYER_L3);
}

void odp_packet_has_ipopt_set(odp_packet_t pkt, int val)
{
	setflag(pkt, input_flags.ipopt, val, LAYER_L3);
}

void odp_packet_has_ipsec_set(odp_packet_t pkt, int val)
{
	setflag(pkt, input_flags.ipsec, val, LAYER_L4);
}

void odp_packet_has_udp_set(odp_packet_t pkt, int val)
{
	setflag(pkt, input_flags.udp, val, LAYER_L4);
}

void odp_packet_has_tcp_set(odp_packet_t pkt, int val)
{
	setflag(pkt, input_flags.tcp, val, LAYER_L4);
}

void odp_packet_has_sctp_set(odp_packet_t pkt, int val)
{
	setflag(pkt, input_flags.sctp, val, LAYER_L4);
}

void odp_packet_has_icmp_set(odp_packet_t pkt, int val)
{
	setflag(pkt, input_flags.icmp, val, LAYER_L4);
}

void odp_packet_has_flow_hash_clr(odp_packet_t pkt)
{
	odp_packet_hdr_t *pkt_hdr = odp_packet_hdr(pkt);

	pkt_hdr->p.input_flags.flow_hash = 0;
}

void odp_packet_has_ts_clr(odp_packet_t pkt)
{
	odp_packet_hdr_t *pkt_hdr = odp_packet_hdr(pkt);

	pkt_hdr->p.input_flags.timestamp = 0;
}

/* Include non-inlined versions of API functions */
#if ODP_ABI_COMPAT == 1
#include <odp/api/plat/packet_flag_inlines_api.h>
#endif
