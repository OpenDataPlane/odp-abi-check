/* Copyright (c) 2016, Linaro Limited
 * All rights reserved.
 *
 * SPDX-License-Identifier:     BSD-3-Clause
 */

#include <odp/api/byteorder.h>
#if ODP_ABI_COMPAT == 1
#include <odp/api/plat/byteorder_inlines.h>
#endif
