#!/bin/bash
#
# Copyright (c) 2021, Nokia
# All rights reserved.
#
# SPDX-License-Identifier:     BSD-3-Clause
#

./odp_cli${EXEEXT} -t 2
